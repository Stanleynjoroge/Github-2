/*
 * Copyright (c) 2008-2015 The Open Source Geospatial Foundation
 *
 * Published under the BSD license.
 * See https://github.com/geoext/geoext2/blob/master/license.txt for the full
 * text of the license.
 */

/*
 * @include OpenLayers/Format/WMSDescribeLayer.js
 * @requires GeoExt/Version.js
 */

/**
 * Data reader class to create an array of layer description objects from a WMS
 * DescribeLayer response.
 *
 * @class GeoExt.data.reader.WmsDescribeLayer
 */
Ext.define('GeoExt.data.reader.WmsDescribeLayer', {
    alternateClassName: [
        'GeoExt.data.reader.WMSDescribeLayer'
    ],
    extend: 'Ext.data.reader.Json',
    alias: 'reader.gx_wmsdescribelayer',
    requires: [
        'GeoExt.Version'
    ],
    /**
     * Should we keep the raw parsed result? If true, the result will be stored
     * under the #raw property. Default is false. When using ExtJS5 a reference
     * to the raw data is always available via the property #data.
     *
     * @cfg {Boolean}
     */
    keepRaw: false,
    /**
     * The raw parsed result, only set if #keepRaw is true.
     * @cfg {Object}
     */
    raw: null,
    /**
     * Creates new Reader.
     *
     * @param {Object} config (optional) Config object.
     */
    constructor: function(config) {
        if (!this.model) {
            this.setModel('GeoExt.data.WmsDescribeLayerModel');
        }
        this.callParent([config]);
        if (!this.format) {
            this.format = new OpenLayers.Format.WMSDescribeLayer();
        }
    },

    /**
     * Gets the records.
     *
     * @param {Object} request The XHR object which contains the parsed XML
     *     document.
     * @return {Object} A data block which is used by an Ext.data.Store
     *     as a cache of Ext.data.Model objects.
     */
    getResponseData: function(request) {
        var data = request.responseXML;
        if(!data || !data.documentElement) {
            data = request.responseText;
        }
        return this.readRecords(data);
    },

    /**
     * Create a data block containing Ext.data.Records from an XML document.
     *
     * @param {DOMElement/String/Object} data A document element or XHR
     *     response string.  As an alternative to fetching capabilities data
     *     from a remote source, an object representing the capabilities can
     *     be provided given that the structure mirrors that returned from the
     *     capabilities parser.
     * @return {Object} A data block which is used by an Ext.data.Store
     *     as a cache of Ext.data.Model objects.
     */
    readRecords: function(data) {
        if (data instanceof Ext.data.ResultSet) {
            // we get into the readRecords method twice,
            // called by Ext.data.reader.Reader#read:
            // check if we already did our work in a previous run
            return data;
        }

        if(typeof data === "string" || data.nodeType) {
            data = this.format.read(data);
        }
        if (!!data.error) {
            Ext.Error.raise({msg: "Error parsing WMS DescribeLayer", arg: data.error});
        }
        if (this.keepRaw) {
            this.raw = data;
        }
        return this.callParent([data]);
    },

    /**
     * @private
     */
    destroyReader: function() {
        var me = this;
        delete me.raw;
        this.callParent();
    }

});
