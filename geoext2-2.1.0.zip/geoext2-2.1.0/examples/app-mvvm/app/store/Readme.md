This folder contains store instances (identified by storeId) and store types
(with "store.foo" aliases).
