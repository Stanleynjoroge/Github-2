Here is the place to store 3rd party packages, e.g. GeoExt by cloning https://github.com/geoext/geoext2.git into a subfolder "GeoExt".
