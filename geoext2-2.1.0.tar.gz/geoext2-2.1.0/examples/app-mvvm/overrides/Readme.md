This folder contains override classes. All overrides in this folder will be automatically included in application builds if the target class of the override is loaded.
